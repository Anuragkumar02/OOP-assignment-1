package com.carrent.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.carrent.entity.Customer;
import com.carrent.entity.Lease;
import com.carrent.exception.LeaseNotFoundException;
import com.carrent.service.CustomerServiceImpl;
import com.carrent.service.ICustomerService;
import com.carrent.util.DBUtil;

public class LeaseDAOImpl implements ILeaseDAO {
	private static Connection connLease;
	
	@Override
	public int addLease(Lease lease) throws ClassNotFoundException, SQLException {
		connLease = DBUtil.createConnection();
		String query = "INSERT INTO lease(start_date, end_date, customer_id, type) " + "VALUES(?,?,?,?)";

		Date startDate = Date.valueOf(lease.getStartDate());
		Date endDate = Date.valueOf(lease.getEndDate());
		
		PreparedStatement prepareStCustomer = connLease.prepareStatement(query);
		prepareStCustomer.setDate(1, startDate);
		prepareStCustomer.setDate(2, endDate);
		prepareStCustomer.setInt(3, lease.getCustomer().getCustomerId());
		prepareStCustomer.setString(4, lease.getType());

		int result = prepareStCustomer.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int updateLease(Lease lease) throws ClassNotFoundException, SQLException, LeaseNotFoundException {
		connLease = DBUtil.createConnection();
		String query = "UPDATE lease SET start_date=?, end_date=?, customer_id=?, type=? "
				+ "WHERE lease_id=?";

		Date startDate = Date.valueOf(lease.getStartDate());
		Date endDate = Date.valueOf(lease.getEndDate());
		
		PreparedStatement prepareStCustomer = connLease.prepareStatement(query);
		prepareStCustomer.setDate(1, startDate);
		prepareStCustomer.setDate(2, endDate);
		prepareStCustomer.setInt(3, lease.getCustomer().getCustomerId());
		prepareStCustomer.setString(4, lease.getType());
		prepareStCustomer.setInt(5, lease.getLeaseId());
		
		int result = prepareStCustomer.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public int deleteLease(int leaseId) throws ClassNotFoundException, SQLException, LeaseNotFoundException {
		Lease lease = null;

		LocalDate startDate = null;
		LocalDate endDate = null;
		
		connLease = DBUtil.createConnection();

		String queryCheck = "SELECT * FROM lease WHERE lease_id = ?";
		String queryDelete = "DELETE FROM lease WHERE lease_id = ?";
		
		String type = null;
		
		int success = 0;
		
		PreparedStatement prepareStLease = connLease.prepareStatement(queryCheck);
		PreparedStatement prepareStDelete = connLease.prepareStatement(queryDelete);
		
		prepareStLease.setInt(1, leaseId);
		prepareStDelete.setInt(1, leaseId);
		
		
		ResultSet rsLease = prepareStLease.executeQuery();

		while (rsLease.next()) {// Till there are further records.
			leaseId = rsLease.getInt("lease_id");
			startDate = rsLease.getDate("start_date").toLocalDate();
			endDate = rsLease.getDate("end_date").toLocalDate();
			type = rsLease.getString("type");
			
			lease = new Lease(startDate, endDate, type);
		}
		

		if (lease == null) {
			throw new LeaseNotFoundException("No Lease Found");
		}else {
			success = prepareStDelete.executeUpdate();
		}
		DBUtil.closeConnection();
		return success;
	}

	@Override
	public Lease viewLease(int leaseId) throws ClassNotFoundException, SQLException, LeaseNotFoundException {
				
		Lease lease = null;

		int customerId = 0;
		LocalDate startDate = null;
		LocalDate endDate = null;
		
		Customer customer = null;

		String firstName = null;
		String lastName = null;
		String email = null;
		String phoneNumber = null;
		
		connLease = DBUtil.createConnection();

		String queryCheck = "SELECT lease_id, start_date, end_date, type, customer_id, "
				+ "firstname, lastname, email, phonenumber FROM lease l JOIN customer c "
				+ "USING(customer_id) WHERE lease_id = ?";
		

		String type = null;
				
		PreparedStatement prepareStCustomer = connLease.prepareStatement(queryCheck);
		prepareStCustomer.setInt(1, leaseId);
		
		ResultSet rsLease = prepareStCustomer.executeQuery();

		while (rsLease.next()) {// Till there are further records.
			customerId = rsLease.getInt("customer_id");
			leaseId = rsLease.getInt("lease_id");
			startDate = rsLease.getDate("start_date").toLocalDate();
			endDate = rsLease.getDate("end_date").toLocalDate();
			type = rsLease.getString("type");
			
			firstName = rsLease.getString("firstname");
			lastName = rsLease.getString("lastname");
			email = rsLease.getString("email");
			phoneNumber = rsLease.getString("phoneNumber");
			
			customer = new Customer(firstName, lastName, email, phoneNumber);
			customer.setCustomerId(customerId);
		
			lease = new Lease(leaseId, startDate, endDate, customer, type);
		}
		DBUtil.closeConnection();

		if (lease == null) {
			throw new LeaseNotFoundException("No Lease Found");
		}

		return lease;
	}

	@Override
	public List<Lease> viewLeases() throws ClassNotFoundException, SQLException, LeaseNotFoundException {
		ICustomerService customerService = new CustomerServiceImpl();
		List<Lease> leases = new ArrayList<>();
		Lease lease = null;

		int customerId = 0;
		LocalDate startDate = null;
		LocalDate endDate = null;
		
		Customer customer = null;

		connLease = DBUtil.createConnection();

		String query = "SELECT * FROM lease";

		String type = null;
		int leaseId = 0;
		
		PreparedStatement prepareStCustomer = connLease.prepareStatement(query);

		ResultSet rsLease = prepareStCustomer.executeQuery();

		while (rsLease.next()) {// Till there are further records.
			customerId = rsLease.getInt("customer_id");
			leaseId = rsLease.getInt("lease_id");
			startDate = rsLease.getDate("start_date").toLocalDate();
			endDate = rsLease.getDate("end_date").toLocalDate();
			type = rsLease.getString("type");
			customer = customerService.viewCustomer(customerId);
		
			lease = new Lease(leaseId, startDate, endDate, customer, type);
			leases.add(lease);
		}
		DBUtil.closeConnection();

		if (leases.size() == 0) {
			throw new LeaseNotFoundException("No Lease Found");
		}

		return leases;
	}

}
