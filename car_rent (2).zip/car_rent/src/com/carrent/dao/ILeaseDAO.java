package com.carrent.dao;

import java.sql.SQLException;
import java.util.List;

import com.carrent.entity.Lease;
import com.carrent.exception.LeaseNotFoundException;

public interface ILeaseDAO {
	public int addLease(Lease lease) throws ClassNotFoundException, SQLException;
	public int updateLease(Lease lease) throws ClassNotFoundException, SQLException, LeaseNotFoundException;
	public int deleteLease(int leaseId) throws ClassNotFoundException, SQLException, LeaseNotFoundException;
	public Lease viewLease(int leaseId) throws ClassNotFoundException, SQLException, LeaseNotFoundException;
	public List<Lease>viewLeases() throws ClassNotFoundException, SQLException, LeaseNotFoundException;
}
