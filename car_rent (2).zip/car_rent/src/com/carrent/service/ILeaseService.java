package com.carrent.service;

import java.util.List;

import com.carrent.entity.Lease;

public interface ILeaseService {
	public int addLease(Lease lease);
	public int updateLease(Lease lease);
	public int deleteLease(int leaseId);
	public Lease viewLease(int leaseId);
	public List<Lease>viewLeases();
}
