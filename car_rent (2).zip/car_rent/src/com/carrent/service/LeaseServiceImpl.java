package com.carrent.service;

import java.sql.SQLException;
import java.util.List;

import com.carrent.dao.ILeaseDAO;
import com.carrent.dao.LeaseDAOImpl;
import com.carrent.entity.Lease;
import com.carrent.exception.LeaseNotFoundException;

public class LeaseServiceImpl implements ILeaseService {

	private ILeaseDAO leaseDAO;

	public LeaseServiceImpl() {
		this.leaseDAO = new LeaseDAOImpl();
	}

	@Override
	public int addLease(Lease lease) {
		int result = 0;
		try {
			result = leaseDAO.addLease(lease);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
	}

	@Override
	public int updateLease(Lease lease) {
		int result = 0;
		try {
			result = leaseDAO.updateLease(lease);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}catch(LeaseNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return result;
	}

	@Override
	public int deleteLease(int leaseId) {
		int result = 0;
		try {
			result = leaseDAO.deleteLease(leaseId);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
				se.printStackTrace();
			}catch(LeaseNotFoundException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		return result;
	}

	@Override
	public Lease viewLease(int leaseId) {
		Lease lease = null;

		try {
			lease = leaseDAO.viewLease(leaseId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (LeaseNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return lease;
	}

	@Override
	public List<Lease> viewLeases() {
		List<Lease> leaseList = null;

		try {
			leaseList = leaseDAO.viewLeases();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (LeaseNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return leaseList;
	}

}
