package com.carrent.entity;

import java.time.LocalDate;
import java.util.Objects;

public class Lease {

	private int leaseId;
	private LocalDate startDate;
	private LocalDate endDate;
	private Customer customer;
	private String type;
	
	public Lease() {
		super();
	}

	public Lease(int leaseId, LocalDate startDate, LocalDate endDate, Customer customer, String type) {
		super();
		this.leaseId = leaseId;
		this.startDate = startDate;
		this.endDate = endDate;
		this.customer = customer;
		this.type = type;
	}
	
	public Lease(LocalDate startDate, LocalDate endDate, Customer customer, String type) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.customer = customer;
		this.type = type;
	}

	public Lease(LocalDate startDate, LocalDate endDate, String type) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.type = type;
	}

	public int getLeaseId() {
		return leaseId;
	}

	public void setLeaseId(int leaseId) {
		this.leaseId = leaseId;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public int hashCode() {
		return Objects.hash(customer, endDate, leaseId, startDate, type);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Lease other = (Lease) obj;
		return Objects.equals(customer, other.customer) && Objects.equals(endDate, other.endDate)
				&& leaseId == other.leaseId && Objects.equals(startDate, other.startDate)
				&& Objects.equals(type, other.type);
	}

	@Override
	public String toString() {
		return "Lease [leaseId=" + leaseId + ", startDate=" + startDate + ", endDate=" + endDate + ", customer="
				+ customer + ", type=" + type + "]";
	}
}