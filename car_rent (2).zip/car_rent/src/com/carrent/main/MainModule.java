package com.carrent.main;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.carrent.entity.Customer;
import com.carrent.entity.Lease;
import com.carrent.service.CustomerServiceImpl;
import com.carrent.service.ICustomerService;
import com.carrent.service.ILeaseService;
import com.carrent.service.LeaseServiceImpl;

public class MainModule {

	public static void main(String[] args) {
		ICustomerService customerService = new CustomerServiceImpl();
		ILeaseService leaseService = new LeaseServiceImpl();
		
		Customer customer = null;
		Lease lease = null;
		
		String firstName = null;
		String lastName = null;
		String email = null;
		String phoneNumber = null;
		
		String typeOfLease = null;
		
		int year = 0 ;
		int month = 0 ;
		int dayOfMonth = 0;
		
		LocalDate startDate = null;
		LocalDate endDate = null;
		
		int success = 0;
		
		int customerID = 0;
		int leaseID = 0;
		
		int choice = -1;
		int innerChoice = -1;

		Scanner scInput = new Scanner(System.in);

		while (choice != 0) {

			System.out.println("Following are the options:");
			System.out.println("1. Customer");
			System.out.println("2. Lease");
			System.out.println("0. Exit");
			System.out.print("Please enter your choice: ");

			choice = scInput.nextInt();
			scInput.nextLine();
			
			switch (choice) {
			case 1:
				while (innerChoice != 0) {
					System.out.println("Following are the options:");
					System.out.println("1. Insert Customer");
					System.out.println("2. Update Customer");
					System.out.println("3. Delete Customer");
					System.out.println("4. View customer by ID");
					System.out.println("5. View all customers");
					System.out.println("0. Exit");
					System.out.print("Please enter your choice: ");

					innerChoice = scInput.nextInt();
					scInput.nextLine();
					
					switch (innerChoice) {
					case 1:
						System.out.print("Enter first name: ");
						firstName = scInput.nextLine();
						
						System.out.print("Enter last name: ");
						lastName = scInput.nextLine();
						
						System.out.print("Enter email: ");
						email = scInput.nextLine();
						
						System.out.print("Enter phone number: ");
						phoneNumber = scInput.nextLine();
						
						customer = new Customer(firstName, lastName, email, phoneNumber);
						
						success = customerService.addCustomer(customer);
						
						if(success == 1 ) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 3:
						System.out.print("Enter customer ID: ");
						customerID = scInput.nextInt();
						scInput.nextLine();
						
						success = customerService.deleteCustomer(customerID);
						
						if(success == 0) {
							System.out.println("No such customer");
						}else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.print("Enter customer ID: ");
						customerID = scInput.nextInt();
						scInput.nextLine();
						
						customer = customerService.viewCustomer(customerID);
						
						if(customer == null) {
							System.out.println("No such customer");
						}else {
							System.out.println("The given customer: ");
							System.out.println(customer);
						}
						break;
					case 5:
						List<Customer>customerList = customerService.viewCustomers();
						
						if(customerList == null) {
							System.out.println("No customers in table.");
						}else {
							System.out.println("Following are the customers:");
							
							for (Customer customer2 : customerList) {
								System.out.println(customer2);
							}	
						}
						
						break;
					default:
						System.out.println("Incorrect option");
						break;
					}
				}
			case 2:
				while (innerChoice != 0) {
					System.out.println("Following are the options:");
					System.out.println("1. Insert Lease");
					System.out.println("2. Update Lease");
					System.out.println("3. Delete Lease");
					System.out.println("4. View Lease by ID");
					System.out.println("5. View all leases");
					System.out.println("0. Exit");
					System.out.print("Please enter your choice: ");

					innerChoice = scInput.nextInt();
					scInput.nextLine();
					
					switch (innerChoice) {
					case 1:
						System.out.println("Enter Start Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());
						
						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());
						
						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());
						
						startDate = LocalDate.of(year, month, dayOfMonth);
						
						System.out.println("Enter End Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());
						
						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());
						
						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());
						
						endDate = LocalDate.of(year, month, dayOfMonth);
						
						System.out.print("Type of Lease: ");
						typeOfLease = scInput.nextLine();
						
						System.out.print("Customer ID: ");
						customerID = Integer.parseInt(scInput.nextLine());
						
						customer = new Customer();
						customer.setCustomerId(customerID);
						
						lease = new Lease(startDate, endDate, customer, typeOfLease);
						
						success = leaseService.addLease(lease);
						
						if(success == 1 ) {
							System.out.println("Record inserted successfully...");
						}
						break;
					case 2:
						System.out.print("Enter Lease ID: ");
						leaseID = scInput.nextInt();
						scInput.nextLine();
						
						System.out.println("Enter Start Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());
						
						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());
						
						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());
						
						startDate = LocalDate.of(year, month, dayOfMonth);
						
						System.out.println("Enter End Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(scInput.nextLine());
						
						System.out.print("Enter month: ");
						month = Integer.parseInt(scInput.nextLine());
						
						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(scInput.nextLine());
						
						endDate = LocalDate.of(year, month, dayOfMonth);
						
						System.out.print("Type of Lease: ");
						typeOfLease = scInput.nextLine();
						
						System.out.print("Customer ID: ");
						customerID = Integer.parseInt(scInput.nextLine());
						
						customer = new Customer();
						customer.setCustomerId(customerID);
						
						lease = new Lease(leaseID, startDate, endDate, customer, typeOfLease);
						
						success = leaseService.updateLease(lease);
						
						if(success == 1 ) {
							System.out.println("Record updated successfully...");
						}else {
							System.out.println("Record was NOT updated...");
						}
						break;
					case 3:
						System.out.print("Enter Lease ID: ");
						leaseID = scInput.nextInt();
						scInput.nextLine();
						
						success = leaseService.deleteLease(leaseID);
						
						if(success == 0) {
							System.out.println("No such lease");
						}else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.print("Enter lease ID: ");
						leaseID = scInput.nextInt();
						scInput.nextLine();
						
						lease = leaseService.viewLease(leaseID);
						
						if(lease == null) {
							System.out.println("No such lease");
						}else {
							System.out.println("The given lease: ");
							System.out.println(lease);
						}
						break;
					case 5:
						List<Lease>leaseList = leaseService.viewLeases();
						
						if(leaseList == null) {
							System.out.println("No leases in table.");
						}else {
							System.out.println("Following are the leases:");
							
							for (Lease lease2 : leaseList) {
								System.out.println(lease2);
							}	
						}
						
						break;
					default:
						System.out.println("Incorrect option");
						break;
					}
				}
			}
		}

		scInput.close();

	}

}
