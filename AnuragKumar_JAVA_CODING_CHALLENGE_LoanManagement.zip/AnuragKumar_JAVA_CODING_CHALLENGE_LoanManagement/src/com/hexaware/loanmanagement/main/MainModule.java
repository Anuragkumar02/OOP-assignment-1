package com.hexaware.loanmanagement.main;

import java.util.List;
import java.util.Scanner;

import com.hexaware.entity.Loan;
import com.hexaware.loanmanagement.dao.ILoanDao;

import com.hexaware.loanmanagement.service.ILoanService;
import com.hexaware.loanmanagement.service.LoanServiceImpl;

public class MainModule {

	public static void main(String[] args) {

		// ILoanDao loanServiceProvider = new ILoanRepositoryImpl();
		ILoanService loanService = new LoanServiceImpl();
		Scanner scanner = new Scanner(System.in);

		Loan loan = null;
		int success = 0;
		double emi = 0, interest = 0;

		while (true) {
			System.out.println();
			System.out.println("*************************************************");
			System.out.println("Loan Management System Menu:");
			System.out.println("1. Apply Loan");
			System.out.println("2. Get All Loans");
			System.out.println("3. Get Loan by ID");
			System.out.println("4. Calculate Intrest");
			System.out.println("5. Loan Status");
			System.out.println("6. Calculate EMI");
			System.out.println("7. Loan Repayment");
			System.out.println("8. Exit");
			System.out.println("*************************************************");
			System.out.println("*************************************************");
			System.out.println();

			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine(); // Consume the newline character

			switch (choice) {

			case 2:
				List<Loan> loanList = loanService.getAllLoan();

				if (loanList == null) {
					System.out.println("No customers in table.");
				} else {
					System.out.println("Following are the customers:");

					for (Loan loan2 : loanList) {
						System.out.println(loan2);
					}
				}

				break;
			case 3:
				// Get Loan by ID
				System.out.print("Enter loan ID: ");
				int loanId1 = scanner.nextInt();

				loan = loanService.getLoanById(loanId1);
				if (loan == null) {
					System.out.println("No such loan");
				} else {
					System.out.println("The given lease: ");
					System.out.println(loan);
				}
			case 4:
				System.out.print("Enter loan ID: ");
				loanId1 = scanner.nextInt();

				interest = loanService.calculateInterest(loanId1);
				System.out.println("The interest is  ");
				System.out.println(interest);

			case 5:
				System.out.print("Enter loan ID: ");
				int loanId3 = scanner.nextInt();

				success = loanService.loanStatus(loanId3);

				if (success == 1) {
					System.out.println("Record updated successfully...");
				} else {
					System.out.println("Record was NOT updated...");
				}

				break;
			case 6:
				System.out.print("Enter loan ID: ");
				loanId1 = scanner.nextInt();

				emi = loanService.calculateEMI(loanId1);
				if (emi == 0) {

					System.out.println("The given Loan Emi is : ");
					System.out.println(emi);
					break;
				}
			case 7:
				System.out.print("Enter loan ID: ");
				loanId1 = scanner.nextInt();
				System.out.println("Enter Amount");
				int amount = scanner.nextInt();
				loanService.loanRepayment(loanId1, amount);
				break;
			}
			
			
		}

	}

}
