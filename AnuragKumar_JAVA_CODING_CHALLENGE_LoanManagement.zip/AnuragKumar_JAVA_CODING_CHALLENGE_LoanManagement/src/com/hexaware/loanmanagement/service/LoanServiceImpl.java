package com.hexaware.loanmanagement.service;

import java.sql.SQLException;
import java.util.List;


import com.hexaware.entity.Loan;
import com.hexaware.loanmanagement.dao.ILoanDao;
import com.hexaware.loanmanagement.dao.LoanDaoImpl;
import com.hexaware.loanmanagement.exception.InvalidLoanException;

public class LoanServiceImpl implements ILoanService {
	
  private ILoanDao iloanDAO;
	
	public LoanServiceImpl() {
		super();
		iloanDAO = new LoanDaoImpl();
	}



	@Override
	public double calculateInterest(int loanId) {
		double result = 0;
		try {
			result = iloanDAO.calculateEMI(loanId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			//se.printStackTrace();
		}catch(InvalidLoanException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return result;
	}

	@Override
	public int loanStatus(int loanId) {
		int result = 0;
		try {
			result = iloanDAO.loanStatus(loanId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			//se.printStackTrace();
		}catch(InvalidLoanException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return result;
	}

	
	@Override
	public void applyLoan(Loan loan) {
		// TODO Auto-generated method stub
		try {
			iloanDAO.applyLoan(loan);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			

	}
	}
	@Override
	public double calculateEMI(int loanId) {
		double result = 0;
		try {
			result = iloanDAO.calculateEMI(loanId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			//se.printStackTrace();
		}catch(InvalidLoanException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return result;
	} 

	

	@Override
	public void loanRepayment(int loanId, double amount) {
		
		try {
			loanRepayment(loanId, amount);
		}
		catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		//se.printStackTrace();
		}catch(InvalidLoanException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		
		
		}

	

	@Override
	public List<Loan> getAllLoan() {
    List<Loan>loanList = null;
		
		try {
		loanList = iloanDAO.getAllLoan();
		}catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		//se.printStackTrace();
		}
		catch(InvalidLoanException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return loanList;
	}
	

	@Override
	public Loan getLoanById(int loanId) {
          Loan loan = null;
		
		try {
			loan = iloanDAO.getLoanById(loanId);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
			//se.printStackTrace();
			}catch(InvalidLoanException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		return loan;
	}



}
