package com.hexaware.loanmanagement.service;

import java.util.List;

import com.hexaware.entity.Loan;

public interface ILoanService {

	void applyLoan(Loan loan);

	double calculateInterest(int loanId);

	int loanStatus(int loanId);

	double calculateEMI(int loanId);

	void loanRepayment(int loanId, double amount);

	public List<Loan>getAllLoan();

	public Loan getLoanById(int loanId);
}
