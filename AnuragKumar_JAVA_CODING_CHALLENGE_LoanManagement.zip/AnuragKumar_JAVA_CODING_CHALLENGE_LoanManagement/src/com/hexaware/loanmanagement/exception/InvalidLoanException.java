package com.hexaware.loanmanagement.exception;

public class InvalidLoanException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidLoanException() {
		// TODO Auto-generated constructor stub
	}
 
	public InvalidLoanException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
