package com.hexaware.loanmanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hexaware.entity.CarLoan;
import com.hexaware.entity.Customer;
import com.hexaware.entity.HomeLoan;
import com.hexaware.entity.Loan;
import com.hexaware.loanmanagement.exception.InvalidLoanException;
import com.hexaware.loanmanagement.util.DBUtil;

public class LoanDaoImpl implements ILoanDao {

	private static Connection connection;

	
	@Override
	public double calculateInterest(int loanId) throws ClassNotFoundException, SQLException, InvalidLoanException {
		connection = DBUtil.createConnection();

		String query = "select * from loan where loanid=?";

		PreparedStatement stmt = connection.prepareStatement(query);
		stmt.setInt(1, loanId);

		Loan loan = null;

		ResultSet rs = stmt.executeQuery();
		double ans = 1;

		while (rs.next()) {

			int loanId1 = rs.getInt("loan_id");
			int customerId = rs.getInt("customer_id");
			int principalAmount = rs.getInt("principal_amount");
			int interestRate = rs.getInt("interest_rate");
			int loanTerm = rs.getInt("loan_term");
			String loanType = rs.getString("loan_type");
			String loanStatus = rs.getString("loan_status");

			Customer customer = new Customer();
			customer.setCustomerId(customerId);

			loan = new Loan(loanId1, customer, principalAmount, interestRate, loanTerm, loanType, loanStatus);
		}

		if (loan == null) {
			throw new InvalidLoanException("No loan Found or invalid entry for fetching loan");
		} else {

			ans = (double) (loan.getPrincipalAmount() * loan.getInterestRate() * loan.getLoanTerm()) / 12;
			// System.out.println(ans);
		}

		connection.close();

		return ans;
	}

	@Override
	public int loanStatus(int loanId) throws ClassNotFoundException, SQLException, InvalidLoanException {

		connection = DBUtil.createConnection();

		// TODO Auto-generated method stub

		int creditScore = 0;
		int result = 0;
		String querycheck = ("select creditScore from Customer where customer_id = ( select customer_id from loan where loan_id = ?)");
		PreparedStatement prepareStloan = connection.prepareStatement(querycheck);
		prepareStloan.setInt(1, loanId);
		prepareStloan.executeQuery();

		if (creditScore > 650) {
			System.out.println("Loan approved as your credit score is more then 650");

			String updateQuery = "UPDATE loan SET loan_status = ? WHERE loan_id = ?";
			prepareStloan = connection.prepareStatement(updateQuery);
			prepareStloan.setInt(1, loanId);
			prepareStloan.setString(1, "Approved");
			prepareStloan.executeUpdate();
		}

		else {
			System.out.println("Loan not approved as your credit score is less then 650");
			String updateQuery = "UPDATE loan SET loan_status=?  WHERE loan_id = ?";
			prepareStloan = connection.prepareStatement(updateQuery);
			prepareStloan.setInt(2, loanId);
			prepareStloan.setString(1, "Rejected");
			prepareStloan.executeUpdate();

			result = prepareStloan.executeUpdate();

			DBUtil.closeConnection();

		}

		return result;
	}

	@Override
	public double calculateEMI(int loanId) throws ClassNotFoundException, SQLException, InvalidLoanException {
		connection = DBUtil.createConnection();
		String query = "SELECT * FROM loan where loan_id=?";

		PreparedStatement prepareStloan = connection.prepareStatement(query);

		prepareStloan.setInt(1, loanId);

		ResultSet rsLoan = prepareStloan.executeQuery();
		ResultSet rs = prepareStloan.executeQuery();
		double emi = 1;

		while (rs.next()) {

			int qloanId = rs.getInt(1);
			int customerId = rs.getInt(2);
			int principal_amount = rs.getInt(3);
			int interest_rate = rs.getInt(4);
			double monthly_intrest_rate = (interest_rate) / 12;
			int loan_term = rs.getInt(5);
			String loan_type = rs.getString(6);
			String loan_status = rs.getString(7);
			// System.out.println(principal_amount);
			// System.out.println(monthly_intrest_rate);
			emi = (double) (principal_amount * monthly_intrest_rate * Math.pow((1 + monthly_intrest_rate), loan_term))
					/ Math.pow((1 + monthly_intrest_rate), loan_term - 1);
			System.out.println(emi);
		}
		return emi;
	}

	@Override
	public void loanRepayment(int loanId, double amount)
			throws ClassNotFoundException, SQLException, InvalidLoanException {
		double emiAmount = calculateEMI(loanId);
		double emi = calculateEMI(loanId);
		if (emi > amount)
			System.out.println("Amount is too less please increase the amount");
		else {
			double noOfEmi = amount / emi;
			System.out.println("With this amount you can pay " + noOfEmi + " months of emi");
		}
	}
	@Override
	public void applyLoan(Loan loan) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub

		PreparedStatement ps = connection.prepareStatement("insert into loan value(?,?,?,?,?,?,?)");

		ps.setInt(1, loan.getLoanId());
		ps.setInt(2, loan.getCustomer().getCustomerId());
		ps.setInt(3, loan.getPrincipalAmount());
		ps.setInt(4, loan.getInterestRate());
		ps.setInt(5, loan.getLoanTerm());
		ps.setString(6, loan.getLoanType());
		ps.setString(7, loan.getLoanStatus());

		int c = ps.executeUpdate();

		int homeLoanId = 0;
		HomeLoan h1 = new HomeLoan(homeLoanId, loan.getLoanId(), loan.getCustomer(), loan.getPrincipalAmount(),
				loan.getInterestRate(), loan.getLoanTerm(), loan.getLoanType(), loan.getLoanStatus(), null, homeLoanId);
		PreparedStatement ps1 = connection.prepareStatement("insert into homeLoan value(?,?,?,?)");

		ps1.setInt(1, h1.getHomeLoanId());
		ps1.setInt(2, h1.getLoanId());
		ps1.setString(3, h1.getPropertyAddress());
		ps1.setInt(4, h1.getPropertyValue());

		int c1 = ps1.executeUpdate();
		System.out.println(c1 + " record updated");

		PreparedStatement stmt = (PreparedStatement) connection.createStatement();
		ResultSet rs = stmt.executeQuery("select * from carLoan order by car_loan_id desc limit 1");

		while (rs.next()) {
			int carLoanId = rs.getInt(1) + 1;
		}

		int carLoanId = 0;
		CarLoan h2 = new CarLoan(carLoanId, loan.getLoanId(), loan.getCustomer(), loan.getPrincipalAmount(),
				loan.getInterestRate(), loan.getLoanTerm(), loan.getLoanType(), loan.getLoanStatus(), null, carLoanId);
		PreparedStatement ps2 = connection.prepareStatement("insert into carLoan value(?,?,?,?)");

		ps2.setInt(1, h2.getCarLoanId());
		ps2.setInt(2, h2.getLoanId());
		ps2.setString(3, h2.getCarModel());
		ps2.setInt(4, h2.getCarValue());

		int c2 = ps2.executeUpdate();
		System.out.println(c2 + " record updated");
	}


	@Override
	public List<Loan> getAllLoan() throws InvalidLoanException, ClassNotFoundException, SQLException {

		List<Loan> loanslist = new ArrayList<>();
		Loan loan = null;
		int customer_id = 0;
		int loan_id = 0;
		int principal_amount = 0;
		int interest_rate = 0;
		int loan_term = 0;
		String loan_type = null;
		String loan_status = null;
		Customer customer = null;
		String name = null;
		String email = null;
		String phone_number = null;
		String address = null;
		int credit_score = 0;

		connection = DBUtil.createConnection();

		String query = "SELECT * FROM loan l join Customer c on l.customer_id=c.customer_id";

		PreparedStatement prepareStloan = connection.prepareStatement(query);

		ResultSet rsLoan = prepareStloan.executeQuery();

		while (rsLoan.next()) {// Till there are further records.
			loan_id = rsLoan.getInt("loan_id");
			customer_id = rsLoan.getInt("customer_id");
			principal_amount = rsLoan.getInt("principal_amount");
			interest_rate = rsLoan.getInt("interest_rate");
			loan_term = rsLoan.getInt("loan_term");
			loan_type = rsLoan.getString("loan_type");
			loan_status = rsLoan.getString("loan_status");
			name = rsLoan.getString("Name");
			email = rsLoan.getString("email");
			phone_number = rsLoan.getString("PhoneNumber");
			address = rsLoan.getString("address");
			credit_score = rsLoan.getInt("creditScore");

			customer = new Customer();
			customer.setCustomerId(customer_id);

			loan = new Loan(loan_id, customer, principal_amount, interest_rate, loan_term, loan_type, loan_status);

			loanslist.add(loan);
		}
		DBUtil.closeConnection();

		if (loanslist.size() == 0) {
			throw new InvalidLoanException("No loan Found or invalid entry for fetching loan");
		}

		return loanslist;
	}

	@Override
	public Loan getLoanById(int loanId) throws ClassNotFoundException, SQLException, InvalidLoanException {
		Loan loan = null;
		int customer_id = 0;
		int principal_amount = 0;
		int interest_rate = 0;
		int loan_term = 0;
		String loan_type = null;
		String loan_status = null;
		Customer customer = null;
		String name = null;
		String email = null;
		String phone_number = null;
		String address = null;
		int credit_score = 0;

		connection = DBUtil.createConnection();

		String query = "SELECT * FROM loan l JOIN Customer c " + "USING(customer_id) WHERE loan_id = ?";

		PreparedStatement prepareStloan = connection.prepareStatement(query);

		prepareStloan.setInt(1, loanId);

		ResultSet rsLoan = prepareStloan.executeQuery();

		while (rsLoan.next()) {// Till there are further records.
			customer_id = rsLoan.getInt("customer_id");
			principal_amount = rsLoan.getInt("principal_amount");
			interest_rate = rsLoan.getInt("interest_rate");
			loan_term = rsLoan.getInt("loan_term");
			loan_type = rsLoan.getString("loan_type");
			loan_status = rsLoan.getString("loan_status");
			name = rsLoan.getString("Name");
			email = rsLoan.getString("email");
			phone_number = rsLoan.getString("PhoneNumber");
			address = rsLoan.getString("address");
			credit_score = rsLoan.getInt("creditScore");

			customer = new Customer();
			customer.setCustomerId(customer_id);

			loan = new Loan(loanId, customer, principal_amount, interest_rate, loan_term, loan_type, loan_status);

		}
		DBUtil.closeConnection();

		if (loan == null) {
			throw new InvalidLoanException("No loan Found or invalid entry for fetching loan");
		}

		return loan;
	}

}
