package com.hexaware.loanmanagement.dao;

import java.sql.SQLException;
import java.util.List;

import com.hexaware.entity.Loan;
import com.hexaware.loanmanagement.exception.InvalidLoanException;

public interface ILoanDao {
	void applyLoan(Loan loan) throws ClassNotFoundException, SQLException;

	double calculateInterest(int loanId) throws ClassNotFoundException, SQLException, InvalidLoanException;

	int loanStatus(int loanId) throws ClassNotFoundException, SQLException, InvalidLoanException;

	double calculateEMI(int loanId) throws ClassNotFoundException, SQLException, InvalidLoanException;

	void loanRepayment(int loanId, double amount) throws ClassNotFoundException, SQLException, InvalidLoanException;

	public List<Loan> getAllLoan() throws ClassNotFoundException, SQLException, InvalidLoanException;

	public Loan getLoanById(int loanId1)
			throws InvalidLoanException, ClassNotFoundException, SQLException, InvalidLoanException;
}