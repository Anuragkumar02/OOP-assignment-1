package com.hexaware.entity;

import java.util.Objects;

public class CarLoan extends Loan {
	private int carLoanId;
	private String carModel;
	private int carValue;

	// Default constructor
	public CarLoan() {
	}

	// Overloaded constructor with parameters
	public CarLoan(int carLoanId, int loanId, Customer customer, int principalAmount, int interestRate, int loanTerm,
			String loanType, String loanStatus, String carModel, int carValue) {
		super(loanId, customer, principalAmount, interestRate, loanTerm, loanType, loanStatus);
		this.carLoanId = carLoanId;
		this.carModel = carModel;
		this.carValue = carValue;
	}

	public CarLoan(int loanId, Customer customer, int principalAmount, int interestRate, int loanTerm, String loanType,
			String loanStatus, String carModel, int carValue) {
		super(loanId, customer, principalAmount, interestRate, loanTerm, loanType, loanStatus);
		
		this.carModel = carModel;
		this.carValue = carValue;
	}

	public int getCarLoanId() {
		return carLoanId;
	}

	public void setCarLoanId(int carLoanId) {
		this.carLoanId = carLoanId;
	}

	// Getters and setters
	public String getCarModel() {
		return carModel;
	}

	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}

	public int getCarValue() {
		return carValue;
	}

	public void setCarValue(int carValue) {
		this.carValue = carValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(carLoanId, carModel, carValue);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CarLoan other = (CarLoan) obj;
		return carLoanId == other.carLoanId && Objects.equals(carModel, other.carModel) && carValue == other.carValue;
	}

	// toString method
	@Override
	public String toString() {
		return "CarLoan{" + "carModel='" + carModel + '\'' + ", carValue=" + carValue + "} " + super.toString();
	}
}
