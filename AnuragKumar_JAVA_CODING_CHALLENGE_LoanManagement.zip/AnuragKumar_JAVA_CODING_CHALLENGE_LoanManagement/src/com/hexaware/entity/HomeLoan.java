package com.hexaware.entity;

import java.util.Objects;

public class HomeLoan extends Loan {
	private int homeLoanId;
	private String propertyAddress;
	private int propertyValue;

	// Default constructor
	public HomeLoan() {
	}

	// Overloaded constructor with parameters
	public HomeLoan(int homeLoanId, int loanId, Customer customer, int principalAmount, int interestRate, int loanTerm,
			String loanType, String loanStatus, String propertyAddress, int propertyValue) {
		super(loanId, customer, principalAmount, interestRate, loanTerm, loanType, loanStatus);
		this.homeLoanId = homeLoanId;
		this.propertyAddress = propertyAddress;
		this.propertyValue = propertyValue;
	}

	public HomeLoan(int loanId, Customer customer, int principalAmount, int interestRate, int loanTerm, String loanType,
			String loanStatus, String propertyAddress, int propertyValue) {
		super(loanId, customer, principalAmount, interestRate, loanTerm, loanType, loanStatus);
		this.propertyAddress = propertyAddress;
		this.propertyValue = propertyValue;
	}

	public int getHomeLoanId() {
		return homeLoanId;
	}

	public void setHomeLoanId(int homeLoanId) {
		this.homeLoanId = homeLoanId;
	}

	// Getters and setters
	public String getPropertyAddress() {
		return propertyAddress;
	}

	public void setPropertyAddress(String propertyAddress) {
		this.propertyAddress = propertyAddress;
	}

	public int getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(int propertyValue) {
		this.propertyValue = propertyValue;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(homeLoanId, propertyAddress, propertyValue);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		HomeLoan other = (HomeLoan) obj;
		return homeLoanId == other.homeLoanId && Objects.equals(propertyAddress, other.propertyAddress)
				&& propertyValue == other.propertyValue;
	}

	// toString method
	@Override
	public String toString() {
		return "HomeLoan{" + "propertyAddress='" + propertyAddress + '\'' + ", propertyValue=" + propertyValue + "} "
				+ super.toString();
	}
}
