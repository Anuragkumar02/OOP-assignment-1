/**
 * 
 */
/**
 * 
 */
module HX_5931_JAVA_CODING_CHALLENGE {
	requires java.sql;
}