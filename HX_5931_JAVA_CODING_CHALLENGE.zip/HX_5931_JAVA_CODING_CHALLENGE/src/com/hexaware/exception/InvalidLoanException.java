package com.hexaware.exception;

public class InvalidLoanException extends Exception {
	public void Myexcep() {
	     // calling the constructor of parent Exception
	     System.err.println("error is in jdbc" );
	 }
}
